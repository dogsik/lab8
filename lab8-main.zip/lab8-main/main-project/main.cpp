
#include <iostream>

using namespace std;

int main()
{
    cout << "Laboratory work #8. GIT\n";
    cout << "Variant #5. Internet Protocol.\n";
    cout << "Author: Kozlova Anastasia\n";
    return 0;
}

